/* eslint-disable */

import React from 'react';

export default class Statistics extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <h2>I am Statistics content</h2>;
  }
}
